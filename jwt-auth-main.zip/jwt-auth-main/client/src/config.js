export default {
  API_URL: "http://localhost:5000",
};
